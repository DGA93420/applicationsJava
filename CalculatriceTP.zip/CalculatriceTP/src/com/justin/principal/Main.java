package com.justin.principal;

import com.justin.ihm.Fenetre;

public class Main {

	public static void main(String[] args) {
		Fenetre fenetre = new Fenetre();
		fenetre.setVisible(true);
	}

}
