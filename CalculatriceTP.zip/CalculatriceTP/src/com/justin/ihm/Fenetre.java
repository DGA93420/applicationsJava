package com.justin.ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class Fenetre extends JFrame {
	// Organisation de la fenêtre en différents panels
	private JPanel PanelPrincipal = new JPanel();
	private JPanel PanelHaut = new JPanel();
	private JPanel PanelBas = new JPanel();
	private JPanel PanelBasGauche = new JPanel();
	private JPanel PanelBasDroite = new JPanel();

	//Les boutons
	private JButton bouton1 = new JButton("1");
	private JButton bouton2 = new JButton("2");
	private JButton bouton3 = new JButton("3");
	private JButton bouton4 = new JButton("4");
	private JButton bouton5 = new JButton("5");
	private JButton bouton6 = new JButton("6");
	private JButton bouton7 = new JButton("7");
	private JButton bouton8 = new JButton("8");
	private JButton bouton9 = new JButton("9");
	private JButton bouton0 = new JButton("0");
	private JButton boutonPoint = new JButton(".");
	private JButton boutonEgal = new JButton("=");
	private JButton boutonClear = new JButton("C");
	private JButton boutonPlus = new JButton("+");
	private JButton boutonMoins = new JButton("-");
	private JButton boutonFois = new JButton("*");
	private JButton boutonDivise = new JButton("/");
	
	//Variables qui contiendront le résultat de l'opération et l'opérateur + - * /
	private double resultat;
	private String operateur = "";

	//Le label qui sera affiché à l'écran
	private JLabel labelResultat = new JLabel("0");

	// Pour les Listeners
	//À t-on cliqué sur un opérateur?
	//Mettre à jour?
	private boolean clicOperateur = false, update = false;

	public void paintComponent(Graphics g) {

	}

	public Fenetre() {
		// Caractéristiques de la fenêtre
		this.setSize(250, 350);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setTitle("Calculette");

		// L'écran d'affichage
		// Caracteristiques pour le Jlabel
		Font font = new Font("Arial", Font.BOLD, 30);
		PanelHaut.setMaximumSize(new Dimension(250, 50));
		labelResultat.setPreferredSize(new Dimension(240, 40));
		labelResultat.setBackground(Color.GREEN);
		labelResultat.setFont(font);
		labelResultat.setHorizontalAlignment(JLabel.RIGHT);
		labelResultat.setBorder(BorderFactory.createBevelBorder(1, Color.black, Color.black));

		// Les claviers
		// Disposition des composants
		PanelBas.setSize(this.getWidth(), 300);
		PanelBas.setLayout(new BoxLayout(PanelBas, BoxLayout.X_AXIS));

		// Le clavier de gauche (chiffres, point et egal)
		PanelBasGauche.setMaximumSize(new Dimension(187, 300));
		/* PanelBasGauche.setBackground(Color.BLACK); */
		PanelBasGauche.setLayout(new GridLayout(4, 3, 4, 4));
		PanelBasGauche.add(bouton7);
		PanelBasGauche.add(bouton8);
		PanelBasGauche.add(bouton9);
		PanelBasGauche.add(bouton4);
		PanelBasGauche.add(bouton5);
		PanelBasGauche.add(bouton6);
		PanelBasGauche.add(bouton1);
		PanelBasGauche.add(bouton2);
		PanelBasGauche.add(bouton3);
		PanelBasGauche.add(bouton0);
		PanelBasGauche.add(boutonPoint);
		PanelBasGauche.add(boutonEgal);
		PanelBasGauche.setBorder(BorderFactory.createBevelBorder(1));

		// Le clavier de droite (signes et clear)
		PanelBasDroite.setMaximumSize(new Dimension(63, 300));
		/* PanelBasDroite.setBackground(Color.GREEN); */
		PanelBasDroite.setLayout(new GridLayout(5, 1, 4, 4));
		Font fontClear = new Font("Arial", Font.BOLD, 30);
		boutonClear.setFont(fontClear);
		boutonClear.setForeground(Color.RED);
		PanelBasDroite.add(boutonClear);
		PanelBasDroite.add(boutonPlus);
		PanelBasDroite.add(boutonMoins);
		PanelBasDroite.add(boutonFois);
		PanelBasDroite.add(boutonDivise);
		PanelBasDroite.setBorder(BorderFactory.createBevelBorder(2));
		// Encapsulation des Panels et objets
		PanelPrincipal.setLayout(new BoxLayout(PanelPrincipal, BoxLayout.Y_AXIS));

		PanelHaut.add(labelResultat);
		PanelBas.add(PanelBasGauche);
		PanelBas.add(PanelBasDroite);
		PanelPrincipal.add(PanelHaut);
		PanelPrincipal.add(PanelBas);

		this.setContentPane(PanelPrincipal);

		// Ajout des Listeners
		bouton1.addActionListener(new BoutonChiffreListener());
		bouton2.addActionListener(new BoutonChiffreListener());
		bouton3.addActionListener(new BoutonChiffreListener());
		bouton4.addActionListener(new BoutonChiffreListener());
		bouton5.addActionListener(new BoutonChiffreListener());
		bouton6.addActionListener(new BoutonChiffreListener());
		bouton7.addActionListener(new BoutonChiffreListener());
		bouton8.addActionListener(new BoutonChiffreListener());
		bouton9.addActionListener(new BoutonChiffreListener());
		bouton0.addActionListener(new BoutonChiffreListener());
		boutonPoint.addActionListener(new BoutonChiffreListener());
		boutonClear.addActionListener(new BoutonClearListener());
		boutonPlus.addActionListener(new BoutonPlusListener());
		boutonMoins.addActionListener(new BoutonMoinsListener());
		boutonFois.addActionListener(new BoutonMultiListener());
		boutonDivise.addActionListener(new BoutonDiviseListener());
		boutonEgal.addActionListener(new BoutonEgalListener());

	}

	//Méthode permettant d'effectuer un calcul selon l'opérateur sélectionné
	  private void calcul(){
	    if(operateur.equals("+")){
	      resultat = resultat + 
	            Double.valueOf(labelResultat.getText()).doubleValue();
	      labelResultat.setText(String.valueOf(resultat));
	    }
	    if(operateur.equals("-")){
	      resultat = resultat - 
	            Double.valueOf(labelResultat.getText()).doubleValue();
	      labelResultat.setText(String.valueOf(resultat));
	    }          
	    if(operateur.equals("*")){
	      resultat = resultat * 
	            Double.valueOf(labelResultat.getText()).doubleValue();
	      labelResultat.setText(String.valueOf(resultat));
	    }     
	    if(operateur.equals("/")){
	      try{
	        resultat = resultat / 
	              Double.valueOf(labelResultat.getText()).doubleValue();
	        labelResultat.setText(String.valueOf(resultat));
	      } catch(ArithmeticException e) {
	        labelResultat.setText("0");
	      }
	    }
	  }

	class BoutonChiffreListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			String str = ((JButton) arg0.getSource()).getText();
			if (update) {
				update = false;

			} else {
				if (!labelResultat.getText().equals("0")) {
					str = labelResultat.getText() + str;
				}
			}
			labelResultat.setText(str);

		}

	}

	class BoutonEgalListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			update = true;
			clicOperateur = false;
			calcul();
		}

	}

	class BoutonClearListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			
			clicOperateur = false;
			update = true;
			resultat = 0;
			operateur = "";
			labelResultat.setText("0");
		}

	}

	class BoutonPlusListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			// Si on a déjà cliqué sur un opérateur
			if (clicOperateur) {
				// On calcule avec l'opérateur précédent le nouveau résultat
				calcul();
				// Et on l'affiche
				labelResultat.setText(String.valueOf(resultat));
			} else {
				resultat = Double.valueOf(labelResultat.getText()).doubleValue();
				clicOperateur = true;
			}
			operateur = "+";
			update = true;
		}
	}

	class BoutonMoinsListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			// Si on a déjà cliqué sur un opérateur
			if (clicOperateur) {
				// On calcule avec l'opérateur précédent le nouveau résultat
				calcul();
				// Et on l'affiche
				labelResultat.setText(String.valueOf(resultat));
			//Sinon
			} else {
				//On enregistre le nombre que l'on a écrit
				resultat = Double.valueOf(labelResultat.getText()).doubleValue();
				//On indique que l'on a cliqué sur un opérateur
				clicOperateur = true;
			}
			//On désigne l'opérateur
			operateur = "-";
			//On dit que le résultat a bien été mis à jour
			update = true;
		}
	}

	class BoutonMultiListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			// Si on a déjà cliqué sur un opérateur
			if (clicOperateur) {
				// On calcule avec l'opérateur précédent le nouveau résultat
				calcul();
				// Et on l'affiche
				labelResultat.setText(String.valueOf(resultat));
			} else {
				resultat = Double.valueOf(labelResultat.getText()).doubleValue();
				clicOperateur = true;
			}
			operateur = "*";
			update = true;
		}
	}



	class BoutonDiviseListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			//Si on a déjà cliqué sur un opérateur
			if(clicOperateur){
				//On calcule avec l'opérateur précédent le nouveau résultat
		        calcul();
		        //Et on l'affiche
		        labelResultat.setText(String.valueOf(resultat));
		      }
		      else{
		        resultat = Double.valueOf(labelResultat.getText()).doubleValue();
		        clicOperateur = true;
		      }
		      operateur = "/";
		      update = true;
		    }
		

	

	}

}


