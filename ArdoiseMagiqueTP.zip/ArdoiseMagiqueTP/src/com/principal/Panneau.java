package com.principal;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JPanel;

public class Panneau extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Le panneau contient un ensemble de points
	private Set<Point> points = new HashSet<Point>();
	//Un pointeur avec des caractéristiques de base
	private Color couleurPointeur = Color.BLACK;
	private String formePointeur = "ROND";
	//Coordonnées du pointeur
	@SuppressWarnings("unused")
	private int posX = -10;
	@SuppressWarnings("unused")
	private int posY = -10;
	private int epaisseurPointeur = 15;

	
	public Panneau(){
		//1er listener de tracé: Lorsque l'on appuie sur la souris dans le panneau de dessin, 
		//on crée un point, et on resdessine tout.
		this.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				//On divise par 2 l'épaisseur du pointeur pour centrer la forme sur le curseur
				points.add(new Point(e.getX()-epaisseurPointeur/2,e.getY()-epaisseurPointeur/2,formePointeur,
						epaisseurPointeur,couleurPointeur));
				repaint();
			}
			
			
		});
		//2ème listener de tracé: Lorsque l'on maintient la souris et on la déplace 
		//on crée un point, et on resdessine tout.
				
		this.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				points.add(new Point(e.getX()-epaisseurPointeur/2,e.getY()-epaisseurPointeur/2,formePointeur,
						epaisseurPointeur,couleurPointeur));
				repaint();
			}
		});
	}
	//Méthode de dessin des points
	public void paintComponent(Graphics g){
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, getWidth(), getHeight());
		for(Point p : points){
			g.setColor(p.getCouleur());
			if(p.getForme()=="ROND"){
				g.fillOval(p.getPosX(), p.getPosY(), p.getEpaisseur(), p.getEpaisseur());
				
			}
			else{
				g.fillRect(p.getPosX(), p.getPosY(), p.getEpaisseur(), p.getEpaisseur());
			}
		}
	}

	public Set<Point> getPoints() {
		return points;
	}

	public void setPoints(Set<Point> points) {
		this.points = points;
	}
	
	public void addPoint(Point point) {
		this.points.add(point);
	}

	public Color getCouleurPointeur() {
		return couleurPointeur;
	}

	public void setCouleurPointeur(Color couleurPointeur) {
		this.couleurPointeur = couleurPointeur;
	}

	public String getFormePointeur() {
		return formePointeur;
	}

	public void setFormePointeur(String formePointeur) {
		this.formePointeur = formePointeur;
	}
	

}
