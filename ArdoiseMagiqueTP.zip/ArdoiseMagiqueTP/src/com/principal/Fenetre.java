package com.principal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import java.util.HashSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JToolBar;

public class Fenetre extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Le container principal et le panneau de dessin
	private JPanel container = new JPanel();
	private Panneau pan = new Panneau();
	//Objets pour le menuBar
	private JMenuBar menuBar = new JMenuBar();
	private JMenu menuFichier = new JMenu("Fichier");
	private JMenu menuEdition = new JMenu("Édition");
	private JMenuItem sousMenuEffacer = new JMenuItem("Effacer");
	private JMenuItem sousMenuQuitter = new JMenuItem("Quitter");
	private JMenu sousMenuFormePointeur = new JMenu("Forme du pointeur");
	private JMenu sousMenuCouleurPointeur = new JMenu("Couleur du pointeur");
	private JMenuItem rond = new JMenuItem("Rond");
	private JMenuItem carre = new JMenuItem("Carré");
	private JMenuItem rouge = new JMenuItem("Rouge");
	private JMenuItem vert = new JMenuItem("Vert");
	private JMenuItem bleu = new JMenuItem("Bleu");
	private JMenuItem noir = new JMenuItem("Noir");
	private JMenuItem violet = new JMenuItem("Violet");
	
	//Objets pour la barre d'outils
	private JToolBar toolBar = new JToolBar();
	private JButton boutonCarre = new JButton(new ImageIcon(this.getClass().getResource("images/iconeCarreNoir.png"))),
			boutonRond = new JButton(new ImageIcon(this.getClass().getResource("images/iconeRondNoir.png"))),
					boutonRouge = new JButton(new ImageIcon(this.getClass().getResource("images/iconeCarreRouge.png"))),
							boutonVert = new JButton(new ImageIcon(this.getClass().getResource("images/iconeCarreVert.png"))),
									boutonBleu = new JButton(new ImageIcon(this.getClass().getResource("images/iconeCarreBleu.png"))),
											boutonNoir = new JButton(new ImageIcon(this.getClass().getResource("images/iconeCarreNoir2.png"))),
													boutonViolet = new JButton(new ImageIcon(this.getClass().getResource("images/iconeCarreViolet.png")));
	
	
	//Constructeur par défaut
	public Fenetre(){
		//Caractéristiques de la fenêtre
		this.setTitle("Mon ardoise magique");
		this.setSize(600,600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		
		//le contentPane
		container.setLayout(new BorderLayout());
		container.add(pan, BorderLayout.CENTER);
		
		
		//Initialisation du menuBar et du toolbar
		this.initMenuBar();
		this.initToolBar();
		
		
		//Final: Rendre visible la fenêtre
		this.setContentPane(container);
		this.setVisible(true);
		
		
	}
	private void initMenuBar(){
		//Affectation des Listeners
		//Pour quitter
		sousMenuQuitter.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		//Pour mettre une couleur au pointeur
		rouge.addActionListener(new CouleurListener());
		vert.addActionListener(new CouleurListener());
		bleu.addActionListener(new CouleurListener());
		noir.addActionListener(new CouleurListener());
		violet.addActionListener(new CouleurListener());
		
		boutonBleu.addActionListener(new CouleurListener());
		boutonVert.addActionListener(new CouleurListener());
		boutonRouge.addActionListener(new CouleurListener());
		boutonNoir.addActionListener(new CouleurListener());
		boutonViolet.addActionListener(new CouleurListener());
		
		//Pour la forme du pointeur
		rond.addActionListener(new FormeListener());
		carre.addActionListener(new FormeListener());
		boutonRond.addActionListener(new FormeListener());
		boutonCarre.addActionListener(new FormeListener());
		
		//Pour effacer
		sousMenuEffacer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				pan.setPoints(new HashSet<>());
				pan.repaint();
				
			}
		});
		
		//encapsulation des modules
		sousMenuCouleurPointeur.add(rouge);
		sousMenuCouleurPointeur.add(vert);
		sousMenuCouleurPointeur.add(bleu);
		sousMenuCouleurPointeur.add(noir);
		sousMenuCouleurPointeur.add(violet);
		
		sousMenuFormePointeur.add(rond);
		sousMenuFormePointeur.add(carre);
		
		menuEdition.add(sousMenuFormePointeur);
		menuEdition.add(sousMenuCouleurPointeur);
		
		menuFichier.add(sousMenuEffacer);
		menuFichier.add(sousMenuQuitter);
		
		menuBar.add(menuFichier);
		menuBar.add(menuEdition);
		
		this.setJMenuBar(menuBar);
	}
	private void initToolBar(){
		//Le fond des boutons doivent être blancs
		this.boutonBleu.setBackground(Color.WHITE);
		this.boutonRouge.setBackground(Color.WHITE);
		this.boutonVert.setBackground(Color.WHITE);
		this.boutonRond.setBackground(Color.WHITE);
		this.boutonCarre.setBackground(Color.WHITE);
		this.boutonNoir.setBackground(Color.WHITE);
		this.boutonViolet.setBackground(Color.WHITE);
		
		//Modules de forme
		this.toolBar.add(boutonRond);
		this.toolBar.add(boutonCarre);
		
		//Séparateur Formes / Couleurs
		this.toolBar.addSeparator();
		
		//Boutons de couleur
		this.toolBar.add(boutonRouge);
		this.toolBar.add(boutonVert);
		this.toolBar.add(boutonBleu);
		this.toolBar.add(boutonNoir);
		this.toolBar.add(boutonViolet);
		
		this.container.add(toolBar, BorderLayout.NORTH);

	}
	//Listeners personnalisés
	//Listener de changement de couleur
	class CouleurListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			//Si on passe par le MenuBar
			if(e.getSource().getClass().getName().equals("javax.swing.JMenuItem")){
				if(e.getSource()==rouge){
					pan.setCouleurPointeur(Color.RED);
				}
				if(e.getSource()==vert){
					pan.setCouleurPointeur(Color.GREEN);
				}
				if(e.getSource()==bleu){
					pan.setCouleurPointeur(Color.BLUE);
				}
				if(e.getSource()==noir){
					pan.setCouleurPointeur(Color.BLACK);
				}
				if(e.getSource()==violet){
					pan.setCouleurPointeur(Color.MAGENTA);
				}
			}
			//Sinon on passe par la ToolBar avec les boutons
			else{
				if(e.getSource()==boutonRouge){
					pan.setCouleurPointeur(Color.RED);
				}
				if(e.getSource()==boutonVert){
					pan.setCouleurPointeur(Color.GREEN);
				}
				if(e.getSource()==boutonBleu){
					pan.setCouleurPointeur(Color.BLUE);
				}
				if(e.getSource()==boutonNoir){
					pan.setCouleurPointeur(Color.BLACK);
				}
				if(e.getSource()==boutonViolet){
					pan.setCouleurPointeur(Color.MAGENTA);
				}
			}
		
			
		}
		
	}
	//Listener pour la forme du pointeur
	class FormeListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			//Si on passe par le MenuBar
			if(e.getSource().getClass().getName().equals("javax.swing.JMenuItem")){
				if(e.getSource()==rond){
					pan.setFormePointeur("ROND");
				}
				else{
					pan.setFormePointeur("CARRÉ");
				}
			}
			//Sinon on passe par les boutons de la ToolBar
			else{
				if(e.getSource()==boutonRond){
					pan.setFormePointeur("ROND");
				}
				else{
					pan.setFormePointeur("CARRÉ");
				}
			}
			
		}
		
	}

}
