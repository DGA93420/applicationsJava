package com.principal;

public class Main {
	//Pour le démarrage
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		Fenetre f = new Fenetre();
	}

}
