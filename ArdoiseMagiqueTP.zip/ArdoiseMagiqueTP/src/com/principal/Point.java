package com.principal;

import java.awt.Color;

public class Point {
	// Un point a une position
	private int posX;
	private int posY;
	// Un point a une épaisseur et une forme de base
	private String forme = "ROND";
	private int epaisseur;
	private Color couleur = Color.BLACK;

	// Constructeurs



	public Point() {
	
	}

	public Point(int posX, int posY, String forme, int epaisseur, Color couleur) {
		this.posX = posX;
		this.posY = posY;
		this.forme = forme;
		this.epaisseur = epaisseur;
		this.couleur = couleur;
	}
	
	// Getters et setters
	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public String getForme() {
		return forme;
	}

	public void setForme(String forme) {
		this.forme = forme;
	}

	public int getEpaisseur() {
		return epaisseur;
	}

	public void setEpaisseur(int epaisseur) {
		this.epaisseur = epaisseur;
	}

	public Color getCouleur() {
		return couleur;
	}

	public void setCouleur(Color couleur) {
		this.couleur = couleur;
	}

}
